import { createContext } from "react";

const ThemeContext = createContext();

export default ThemeContext;